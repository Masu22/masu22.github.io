﻿import os
import re

# 読み込むディレクトリを指定（例：'./tex_files'）
tex_dir = './tex_files'
output_file = 'extracted_titles_sections.txt'

# 正規表現パターン
title_pattern = re.compile(r'\\title\{(.+?)\}')
section_pattern = re.compile(r'\\section\{(.+?)\}')

with open(output_file, 'w', encoding='utf-8') as out_file:
    for filename in sorted(os.listdir(tex_dir)):
        if filename.endswith('.tex'):
            filepath = os.path.join(tex_dir, filename)
            with open(filepath, 'r', encoding='utf-8') as f:
                content = f.read()

                # タイトル抽出
                title_match = title_pattern.search(content)
                title = title_match.group(1).strip() if title_match else '（なし）'

                # セクション抽出（複数対応）
                sections = section_pattern.findall(content)
                sections = [s.strip() for s in sections]

                # 出力
                out_file.write(f'ファイル名: {filename}\n')
                out_file.write(f'- タイトル: {title}\n')
                for sec in sections:
                    out_file.write(f'- セクション: {sec}\n')
                out_file.write('\n')  # ファイルごとの区切り
